CREATE TABLE IF NOT EXISTS cursos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  docente VARCHAR(100) NOT NULL
);

INSERT INTO cursos (nombre, docente) VALUES
('Matematicas', 'Carlos Perez'),
('Programacion', 'Ana Gomez'),
('Bases de Datos', 'Luis Martinez'),
('Fisica 1', 'Juan Jose Gomez'),
('Programacion', 'Daniel Martinez'),
('Contabilidad', 'Sara Isabel Alegria');