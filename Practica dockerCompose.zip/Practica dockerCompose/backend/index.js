const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3000;

let db;

function conectarDB() {
  db = mysql.createConnection({
    host: "db",
    user: "root",
    password: "1234",
    database: "plataforma_educativa"
  });

  db.connect((err) => {
    if (err) {
      console.error("Error al conectar con MySQL:", err.message);
      console.log("Reintentando conexión en 5 segundos...");
      setTimeout(conectarDB, 5000);
      return;
    }

    console.log("Conectado a MySQL correctamente");
  });
}

conectarDB();

app.get("/", (req, res) => {
  res.send("Backend educativo funcionando");
});

app.get("/cursos", (req, res) => {
  if (!db) {
    return res.status(500).json({ error: "Base de datos no disponible" });
  }

  const sql = "SELECT id, nombre, docente FROM cursos";

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error en consulta:", err.message);
      return res.status(500).json({ error: "Error al consultar cursos" });
    }

    res.json(results);
  });
});

app.listen(PORT, () => {
  console.log(`Servidor backend corriendo en puerto ${PORT}`);
});